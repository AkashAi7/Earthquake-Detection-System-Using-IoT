package com.example.eqdetector.Model;

public class EarthquakeData {
}
