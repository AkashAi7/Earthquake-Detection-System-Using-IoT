package com.example.eqdetector;

import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.eqdetector.Utilities.DataUtils;

public class SismosActivity extends BaseActivity {

    private RecyclerView recyclerView;

    private EarthquakeAdapter earthquakeAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setElevation(0);
        actionBar.setTitle("Sismos");

        recyclerView = findViewById(R.id.recyclerview);

        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        // COMPLETED (41) Set the layoutManager on mRecyclerView

        String[] data = DataUtils.getSimpleEarthquakeData(this);
        earthquakeAdapter = new EarthquakeAdapter(this,data);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(earthquakeAdapter);
    }





        @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    int getLayoutId() {
        return R.layout.activity_sismos;
    }

    @Override
    int getBottomNavigationMenuItemId() {
        return R.id.navigation_sismos;
    }


}