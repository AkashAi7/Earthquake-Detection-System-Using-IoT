package com.example.eqdetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{

    private ImageView mIcon;

    private Animation zoomIn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        zoomIn = AnimationUtils.loadAnimation(this,R.anim.zoom_in);

        mIcon = findViewById(R.id.icon);

        mIcon.setAnimation(zoomIn);



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // This method will be executed once the timer is over

                Intent i;
                if(LoginActivity.LOGIN_STATUS.equals("logged-out")) {
                    i = new Intent(MainActivity.this, LoginActivity.class);
                    nextActivity(i);
                }else if(LoginActivity.LOGIN_STATUS.equals("logged-in")){
                    i = new Intent(MainActivity.this, AlertsActivity.class);
                    nextActivity(i);
                }
            }
        }, 2000);
    }

    private void nextActivity(Intent i){
        startActivity(i);
        finish();
    }
}
