package com.example.eqdetector.Models;

public class User {
    public String name,email, location;

    public User(){

    }
    public User(String name,String email,String location){
        this.name= name;
        this.email= email;
        this.location= location;
    }


}
