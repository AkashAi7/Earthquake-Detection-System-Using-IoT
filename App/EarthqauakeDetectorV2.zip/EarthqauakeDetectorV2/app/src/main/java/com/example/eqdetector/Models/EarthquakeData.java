package com.example.eqdetector.Models;

public class EarthquakeData {
}
